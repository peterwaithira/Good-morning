export type AttendanceStatus = "present" | "absent" | "late";

export type CbcLevel = "EE1" | "EE2" | "ME1" | "ME2" | "AE1" | "AE2" | "BE1" | "BE2";

export type Student = {
  id: string;
  name: string;
  grade: string;
  section: string;
  guardian: string;
  guardianPhone: string;
  healthNote: string;
  attendanceToday: AttendanceStatus;
  attendanceRate: number;
  feeBalance: number;
  cbc: Record<string, CbcLevel>;
};

export type Invoice = {
  id: string;
  studentId: string;
  studentName: string;
  term: string;
  amount: number;
  dueDate: string;
  status: "paid" | "pending" | "overdue";
};

export type Staff = {
  id: string;
  name: string;
  role: string;
  department: string;
  subjects: string[];
  status: "on duty" | "on leave" | "absent";
  leaveBalance: number;
  grossPay: number;
};

export type Route = {
  id: string;
  name: string;
  driver: string;
  vehicle: string;
  capacity: number;
  onboard: number;
  stops: number;
  status: "on route" | "completed" | "delayed";
};

export type Hostel = {
  id: string;
  name: string;
  gender: "Boys" | "Girls";
  capacity: number;
  occupied: number;
  matron: string;
};

export const SCHOOL_TOTAL_STUDENTS = 260;

export const CBC_LEVELS: { level: CbcLevel; points: number; label: string; tone: string }[] = [
  { level: "EE1", points: 8, label: "Exceeding Expectation 1", tone: "bg-emerald-600 text-white" },
  { level: "EE2", points: 7, label: "Exceeding Expectation 2", tone: "bg-emerald-500 text-white" },
  { level: "ME1", points: 6, label: "Meeting Expectation 1", tone: "bg-teal-600 text-white" },
  { level: "ME2", points: 5, label: "Meeting Expectation 2", tone: "bg-teal-500 text-white" },
  { level: "AE1", points: 4, label: "Approaching Expectation 1", tone: "bg-amber-500 text-white" },
  { level: "AE2", points: 3, label: "Approaching Expectation 2", tone: "bg-amber-400 text-amber-950" },
  { level: "BE1", points: 2, label: "Below Expectation 1", tone: "bg-rose-500 text-white" },
  { level: "BE2", points: 1, label: "Below Expectation 2", tone: "bg-rose-600 text-white" },
];

export const SUBJECTS = [
  "Mathematics",
  "English & Literature",
  "Kiswahili",
  "Pre-Technical Studies",
  "Social Studies",
  "Creative Art & Sport",
  "CRE",
  "Science",
  "Agriculture",
];

export function levelPoints(level: CbcLevel): number {
  return CBC_LEVELS.find((l) => l.level === level)?.points ?? 0;
}

export function studentAverage(s: Student): number {
  const pts = SUBJECTS.map((sub) => levelPoints(s.cbc[sub])).filter((p) => p > 0);
  if (!pts.length) return 0;
  return pts.reduce((a, b) => a + b, 0) / pts.length;
}

export function overallLevel(s: Student): CbcLevel {
  const avg = studentAverage(s);
  const rounded = Math.round(avg);
  const found = CBC_LEVELS.find((l) => l.points === rounded);
  return found ? found.level : "BE2";
}

export const initialStudents: Student[] = [
  {
    id: "NCS-1001", name: "Amara Okafor", grade: "Grade 9", section: "A",
    guardian: "Ngozi Okafor", guardianPhone: "+254 703 111 2233", healthNote: "Mild asthma — inhaler on file",
    attendanceToday: "present", attendanceRate: 96, feeBalance: 0,
    cbc: { Mathematics: "EE1", "English & Literature": "EE2", Kiswahili: "ME1", "Pre-Technical Studies": "ME1", "Social Studies": "ME2", "Creative Art & Sport": "EE2", CRE: "ME1", Science: "EE1", Agriculture: "ME1" },
  },
  {
    id: "NCS-1002", name: "Daniel Mensah", grade: "Grade 9", section: "A",
    guardian: "Kofi Mensah", guardianPhone: "+254 711 555 121", healthNote: "None recorded",
    attendanceToday: "late", attendanceRate: 88, feeBalance: 450,
    cbc: { Mathematics: "ME1", "English & Literature": "ME2", Kiswahili: "AE1", "Pre-Technical Studies": "ME2", "Social Studies": "ME1", "Creative Art & Sport": "ME1", CRE: "ME2", Science: "AE1", Agriculture: "ME2" },
  },
  {
    id: "NCS-1003", name: "Zainab Bello", grade: "Grade 10", section: "B",
    guardian: "Fatima Bello", guardianPhone: "+254 705 909 8877", healthNote: "Peanut allergy",
    attendanceToday: "present", attendanceRate: 99, feeBalance: 0,
    cbc: { Mathematics: "EE1", "English & Literature": "EE1", Kiswahili: "EE2", "Pre-Technical Studies": "ME1", "Social Studies": "EE1", "Creative Art & Sport": "EE1", CRE: "EE2", Science: "EE1", Agriculture: "EE2" },
  },
  {
    id: "NCS-1004", name: "Tunde Adeyemi", grade: "Grade 10", section: "B",
    guardian: "Bola Adeyemi", guardianPhone: "+254 702 334 9911", healthNote: "None recorded",
    attendanceToday: "absent", attendanceRate: 74, feeBalance: 1200,
    cbc: { Mathematics: "AE2", "English & Literature": "ME2", Kiswahili: "BE1", "Pre-Technical Studies": "AE1", "Social Studies": "AE2", "Creative Art & Sport": "ME1", CRE: "AE1", Science: "BE1", Agriculture: "AE2" },
  },
  {
    id: "NCS-1005", name: "Grace Wanjiru", grade: "Grade 11", section: "A",
    guardian: "Peter Wanjiru", guardianPhone: "+254 722 456 789", healthNote: "Wears glasses",
    attendanceToday: "present", attendanceRate: 92, feeBalance: 300,
    cbc: { Mathematics: "ME1", "English & Literature": "EE2", Kiswahili: "ME1", "Pre-Technical Studies": "ME2", "Social Studies": "ME1", "Creative Art & Sport": "EE2", CRE: "ME1", Science: "ME2", Agriculture: "ME1" },
  },
  {
    id: "NCS-1006", name: "Ibrahim Sule", grade: "Grade 11", section: "C",
    guardian: "Aisha Sule", guardianPhone: "+254 707 220 4455", healthNote: "None recorded",
    attendanceToday: "present", attendanceRate: 85, feeBalance: 0,
    cbc: { Mathematics: "ME2", "English & Literature": "ME1", Kiswahili: "ME2", "Pre-Technical Studies": "AE1", "Social Studies": "ME1", "Creative Art & Sport": "ME2", CRE: "ME1", Science: "AE1", Agriculture: "ME2" },
  },
  {
    id: "NCS-1007", name: "Chloe Nkemdirim", grade: "Grade 12", section: "A",
    guardian: "Uche Nkemdirim", guardianPhone: "+254 709 771 3322", healthNote: "None recorded",
    attendanceToday: "present", attendanceRate: 98, feeBalance: 0,
    cbc: { Mathematics: "EE1", "English & Literature": "EE1", Kiswahili: "EE2", "Pre-Technical Studies": "EE1", "Social Studies": "EE2", "Creative Art & Sport": "EE1", CRE: "EE1", Science: "EE2", Agriculture: "EE1" },
  },
  {
    id: "NCS-1008", name: "Samuel Otieno", grade: "Grade 12", section: "B",
    guardian: "Mary Otieno", guardianPhone: "+254 733 998 100", healthNote: "Mild hearing aid",
    attendanceToday: "absent", attendanceRate: 80, feeBalance: 750,
    cbc: { Mathematics: "ME1", "English & Literature": "ME2", Kiswahili: "ME1", "Pre-Technical Studies": "AE1", "Social Studies": "ME1", "Creative Art & Sport": "ME2", CRE: "ME1", Science: "ME2", Agriculture: "ME1" },
  },
];

export const initialInvoices: Invoice[] = [
  { id: "INV-2401", studentId: "NCS-1002", studentName: "Daniel Mensah", term: "Term 2 · 2025", amount: 450, dueDate: "2025-06-15", status: "overdue" },
  { id: "INV-2402", studentId: "NCS-1004", studentName: "Tunde Adeyemi", term: "Term 2 · 2025", amount: 1200, dueDate: "2025-06-15", status: "overdue" },
  { id: "INV-2403", studentId: "NCS-1005", studentName: "Grace Wanjiru", term: "Term 2 · 2025", amount: 300, dueDate: "2025-07-01", status: "pending" },
  { id: "INV-2404", studentId: "NCS-1008", studentName: "Samuel Otieno", term: "Term 2 · 2025", amount: 750, dueDate: "2025-07-01", status: "pending" },
  { id: "INV-2405", studentId: "NCS-1001", studentName: "Amara Okafor", term: "Term 2 · 2025", amount: 600, dueDate: "2025-05-20", status: "paid" },
  { id: "INV-2406", studentId: "NCS-1003", studentName: "Zainab Bello", term: "Term 2 · 2025", amount: 600, dueDate: "2025-05-20", status: "paid" },
  { id: "INV-2407", studentId: "NCS-1007", studentName: "Chloe Nkemdirim", term: "Term 2 · 2025", amount: 600, dueDate: "2025-05-20", status: "paid" },
];

export type TimetableSlot = {
  time: string;
  subject: string;
  teacher: string;
  room: string;
  grade: string;
  day: string;
  conflict?: boolean;
  substitute?: string;
};

export const timetable: TimetableSlot[] = [
  { time: "08:00", subject: "Mathematics", teacher: "Mr. Eze", room: "R-12", grade: "Grade 9A", day: "Mon" },
  { time: "09:00", subject: "English & Literature", teacher: "Ms. Adeleke", room: "R-04", grade: "Grade 10B", day: "Mon" },
  { time: "10:15", subject: "Science", teacher: "Mr. Boateng", room: "Lab-2", grade: "Grade 11A", day: "Mon" },
  { time: "11:15", subject: "Kiswahili", teacher: "Mwl. Kimani", room: "R-07", grade: "Grade 12A", day: "Mon" },
  { time: "13:00", subject: "Pre-Technical Studies", teacher: "Ms. Nwosu", room: "Workshop-1", grade: "Grade 11C", day: "Mon" },
  { time: "08:00", subject: "Agriculture", teacher: "Mr. Kariuki", room: "Farm-Plot", grade: "Grade 9A", day: "Tue" },
  { time: "09:00", subject: "Social Studies", teacher: "Mrs. Banda", room: "R-09", grade: "Grade 10B", day: "Tue" },
  { time: "10:15", subject: "CRE", teacher: "Pastor Njoroge", room: "Hall-1", grade: "Grade 11A", day: "Tue" },
  { time: "11:15", subject: "Creative Art & Sport", teacher: "Coach Mwangi", room: "Field", grade: "Grade 12A", day: "Tue" },
  { time: "13:00", subject: "Mathematics", teacher: "Mr. Eze", room: "R-12", grade: "Grade 12B", day: "Tue", conflict: true, substitute: "Ms. Adeleke" },
];

export const initialStaff: Staff[] = [
  { id: "STF-01", name: "Mr. Chidi Eze", role: "Head of Mathematics", department: "Sciences", subjects: ["Mathematics"], status: "on duty", leaveBalance: 12, grossPay: 4200 },
  { id: "STF-02", name: "Ms. Bisi Adeleke", role: "English Teacher", department: "Languages", subjects: ["English & Literature"], status: "on duty", leaveBalance: 8, grossPay: 3800 },
  { id: "STF-03", name: "Mwl. Joseph Kimani", role: "Kiswahili Teacher", department: "Languages", subjects: ["Kiswahili"], status: "on leave", leaveBalance: 3, grossPay: 3600 },
  { id: "STF-04", name: "Mr. Kwame Boateng", role: "Science Teacher", department: "Sciences", subjects: ["Science"], status: "on duty", leaveBalance: 10, grossPay: 3900 },
  { id: "STF-05", name: "Mr. Peter Kariuki", role: "Agriculture Teacher", department: "Applied Sciences", subjects: ["Agriculture"], status: "on duty", leaveBalance: 14, grossPay: 3700 },
  { id: "STF-06", name: "Ms. Ada Nwosu", role: "Pre-Technical Teacher", department: "Technical", subjects: ["Pre-Technical Studies"], status: "absent", leaveBalance: 6, grossPay: 3750 },
  { id: "STF-07", name: "Mrs. Linda Banda", role: "Social Studies Teacher", department: "Humanities", subjects: ["Social Studies"], status: "on duty", leaveBalance: 9, grossPay: 3650 },
  { id: "STF-08", name: "Coach David Mwangi", role: "Sports & Creative Arts", department: "Creative Arts", subjects: ["Creative Art & Sport"], status: "on duty", leaveBalance: 11, grossPay: 3400 },
];

export const initialRoutes: Route[] = [
  { id: "RT-01", name: "Westlands – Parklands", driver: "Mr. Otieno", vehicle: "KDA 341X", capacity: 45, onboard: 41, stops: 7, status: "on route" },
  { id: "RT-02", name: "Karen – Langata", driver: "Mr. Wekesa", vehicle: "KDB 778M", capacity: 45, onboard: 38, stops: 6, status: "on route" },
  { id: "RT-03", name: "Eastleigh – Kasarani", driver: "Mr. Hassan", vehicle: "KDC 210P", capacity: 40, onboard: 40, stops: 8, status: "delayed" },
  { id: "RT-04", name: "Rongai – Ngong", driver: "Mr. Mutua", vehicle: "KDD 559T", capacity: 45, onboard: 29, stops: 5, status: "completed" },
];

export const initialHostels: Hostel[] = [
  { id: "HS-01", name: "Kilimanjaro House", gender: "Boys", capacity: 80, occupied: 74, matron: "Mr. Ochieng" },
  { id: "HS-02", name: "Kenya House", gender: "Girls", capacity: 80, occupied: 78, matron: "Mrs. Njeri" },
  { id: "HS-03", name: "Elgon House", gender: "Boys", capacity: 60, occupied: 51, matron: "Mr. Barasa" },
  { id: "HS-04", name: "Aberdare House", gender: "Girls", capacity: 60, occupied: 57, matron: "Ms. Chebet" },
];