import { useState } from "react";
import { ClipboardList, Award, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  CBC_LEVELS,
  SUBJECTS,
  levelPoints,
  overallLevel,
  studentAverage,
  type CbcLevel,
  type Student,
} from "@/data/school";

function levelMeta(level: CbcLevel) {
  return CBC_LEVELS.find((l) => l.level === level) ?? CBC_LEVELS[CBC_LEVELS.length - 1];
}

export function GradebookView({
  students,
  setStudents,
}: {
  students: Student[];
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>;
}) {
  const [selectedId, setSelectedId] = useState(students[0]?.id ?? "");
  const selected = students.find((s) => s.id === selectedId) ?? students[0];

  const setLevel = (studentId: string, subject: string, level: CbcLevel) =>
    setStudents((prev) =>
      prev.map((s) => (s.id === studentId ? { ...s, cbc: { ...s.cbc, [subject]: level } } : s)),
    );

  const classAvg = students.length
    ? students.reduce((a, s) => a + studentAverage(s), 0) / students.length
    : 0;

  const distribution = CBC_LEVELS.map((l) => ({
    ...l,
    count: students.filter((s) => overallLevel(s) === l.level).length,
  }));

  return (
    <div className="space-y-6">
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="border-lime-200 bg-white shadow-sm lg:col-span-2">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-green-700">Class average (CBC points)</p>
                <p className="mt-1 text-3xl font-bold text-slate-900">{classAvg.toFixed(2)} / 8.00</p>
                <p className="text-sm text-slate-500">Competency-Based Curriculum · 8 learning areas</p>
              </div>
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-lime-200 text-green-800">
                <TrendingUp className="h-6 w-6" />
              </div>
            </div>
            <Progress value={(classAvg / 8) * 100} className="mt-4 h-2" />
          </CardContent>
        </Card>
        <Card className="border-lime-200 bg-white shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="font-serif text-base text-green-900">Level Distribution</CardTitle>
          </CardHeader>
          <CardContent className="space-y-1.5">
            {distribution.map((d) => (
              <div key={d.level} className="flex items-center gap-2 text-xs">
                <span className={`inline-flex w-11 justify-center rounded px-1.5 py-0.5 font-semibold ${d.tone}`}>
                  {d.level}
                </span>
                <span className="flex-1 text-slate-500">{d.points} pts</span>
                <span className="font-semibold text-slate-700">{d.count}</span>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card className="border-lime-200 bg-white shadow-sm">
        <CardHeader className="flex flex-row flex-wrap items-center justify-between gap-3 space-y-0">
          <div>
            <CardTitle className="font-serif text-lg text-green-900">Mark Entry · Competency Gradebook</CardTitle>
            <p className="text-sm text-slate-500">Assign CBC levels per learning area · EE1 (8) down to BE2 (1)</p>
          </div>
          <Select value={selectedId} onValueChange={setSelectedId}>
            <SelectTrigger className="w-full border-lime-200 bg-white sm:w-56">
              <SelectValue placeholder="Select student" />
            </SelectTrigger>
            <SelectContent>
              {students.map((s) => (
                <SelectItem key={s.id} value={s.id}>
                  {s.name} · {s.grade} {s.section}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardHeader>
        <CardContent className="space-y-3">
          {selected && (
            <>
              <div className="flex flex-wrap items-center gap-3 rounded-xl bg-lime-50 p-4">
                <Award className="h-5 w-5 text-green-700" />
                <div className="flex-1">
                  <p className="text-sm font-semibold text-slate-800">{selected.name}</p>
                  <p className="text-xs text-slate-500">
                    Average {studentAverage(selected).toFixed(2)} pts · overall {overallLevel(selected)}
                  </p>
                </div>
                <Badge className={`${levelMeta(overallLevel(selected)).tone} hover:${levelMeta(overallLevel(selected)).tone}`}>
                  {overallLevel(selected)} · {levelPoints(overallLevel(selected))} pts
                </Badge>
              </div>

              <div className="grid gap-3 lg:grid-cols-2">
                {SUBJECTS.map((subject) => {
                  const current = selected.cbc[subject];
                  return (
                    <div
                      key={subject}
                      className="rounded-xl border border-lime-100 bg-white p-3 shadow-sm"
                    >
                      <div className="mb-2 flex items-baseline justify-between gap-2">
                        <p className="text-sm font-semibold text-slate-800">{subject}</p>
                        <span className="text-xs text-slate-500">{levelMeta(current).label}</span>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {CBC_LEVELS.map((l) => (
                          <button
                            key={l.level}
                            onClick={() => setLevel(selected.id, subject, l.level)}
                            title={`${l.label} · ${l.points} pts`}
                            className={`rounded-lg px-2.5 py-1.5 text-xs font-semibold transition ${
                              current === l.level
                                ? l.tone
                                : "bg-lime-50 text-green-800 hover:bg-lime-100"
                            }`}
                          >
                            {l.level}
                          </button>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </CardContent>
      </Card>

      <Card className="border-lime-200 bg-white shadow-sm">
        <CardHeader>
          <CardTitle className="font-serif text-lg text-green-900">Report Card Summary</CardTitle>
          <p className="text-sm text-slate-500">Automated generation from entered competency levels</p>
        </CardHeader>
        <CardContent className="space-y-2">
          {students.map((s) => {
            const overall = overallLevel(s);
            const meta = levelMeta(overall);
            return (
              <div
                key={s.id}
                className="flex flex-wrap items-center gap-3 rounded-xl border border-lime-100 bg-white p-3 shadow-sm sm:flex-nowrap"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-lime-100 text-green-800">
                  <ClipboardList className="h-4 w-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-slate-800">{s.name}</p>
                  <p className="text-xs text-slate-500">{s.grade} {s.section} · {s.id}</p>
                </div>
                <div className="hidden flex-wrap gap-1 lg:flex">
                  {SUBJECTS.map((sub) => (
                    <span
                      key={sub}
                      title={sub}
                      className={`rounded px-1.5 py-0.5 text-xs font-semibold ${levelMeta(s.cbc[sub]).tone}`}
                    >
                      {s.cbc[sub]}
                    </span>
                  ))}
                </div>
                <span className="text-sm font-semibold text-slate-700">{studentAverage(s).toFixed(2)}</span>
                <Badge className={`${meta.tone} hover:${meta.tone}`}>{overall}</Badge>
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}