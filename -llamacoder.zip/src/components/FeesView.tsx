import { useState } from "react";
import { Receipt, CreditCard, AlertTriangle, CheckCircle2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import type { Invoice, Student } from "@/data/school";

const statusChip: Record<Invoice["status"], string> = {
  paid: "border-green-200 bg-green-50 text-green-700",
  pending: "border-lime-300 bg-lime-50 text-green-800",
  overdue: "border-rose-200 bg-rose-50 text-rose-700",
};

export function FeesView({
  invoices,
  setInvoices,
  students,
}: {
  invoices: Invoice[];
  setInvoices: React.Dispatch<React.SetStateAction<Invoice[]>>;
  students: Student[];
}) {
  const [filter, setFilter] = useState<"all" | Invoice["status"]>("all");

  const collected = invoices.filter((i) => i.status === "paid").reduce((a, i) => a + i.amount, 0);
  const outstanding = invoices.filter((i) => i.status !== "paid").reduce((a, i) => a + i.amount, 0);
  const total = collected + outstanding;
  const collectionRate = total ? Math.round((collected / total) * 100) : 0;

  const visible = invoices.filter((i) => filter === "all" || i.status === filter);

  const payInvoice = (id: string) =>
    setInvoices((prev) => prev.map((i) => (i.id === id ? { ...i, status: "paid" } : i)));

  return (
    <div className="space-y-6">
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="border-lime-200 bg-white shadow-sm lg:col-span-2">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-green-700">Term 2 collection</p>
                <p className="mt-1 text-3xl font-bold text-slate-900">${collected.toLocaleString()}</p>
                <p className="text-sm text-slate-500">of ${total.toLocaleString()} invoiced</p>
              </div>
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-lime-200 text-green-800">
                <Receipt className="h-6 w-6" />
              </div>
            </div>
            <Progress value={collectionRate} className="mt-4 h-2" />
            <p className="mt-2 text-xs text-slate-500">{collectionRate}% of billed fees collected this term</p>
          </CardContent>
        </Card>
        <Card className="border-amber-200 bg-amber-50 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 text-amber-800">
              <AlertTriangle className="h-5 w-5" />
              <p className="text-xs font-semibold uppercase tracking-wide">Outstanding</p>
            </div>
            <p className="mt-2 text-3xl font-bold text-amber-900">${outstanding.toLocaleString()}</p>
            <p className="mt-1 text-sm text-amber-700">
              {invoices.filter((i) => i.status !== "paid").length} invoices awaiting payment
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="border-lime-200 bg-white shadow-sm">
        <CardHeader className="flex flex-row flex-wrap items-center justify-between gap-3 space-y-0">
          <div>
            <CardTitle className="font-serif text-lg text-green-900">Invoices & Receipts</CardTitle>
            <p className="text-sm text-slate-500">Installment tracking · online payment gateway</p>
          </div>
          <div className="flex gap-1 rounded-lg bg-lime-100 p-1">
            {(["all", "paid", "pending", "overdue"] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`rounded-md px-3 py-1.5 text-xs font-medium capitalize transition ${
                  filter === f ? "bg-white text-green-800 shadow-sm" : "text-green-700/70 hover:text-green-900"
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </CardHeader>
        <CardContent className="space-y-2">
          {visible.length === 0 && (
            <div className="rounded-xl border border-dashed border-lime-300 py-10 text-center">
              <CheckCircle2 className="mx-auto h-7 w-7 text-lime-500" />
              <p className="mt-2 text-sm font-medium text-slate-600">No invoices in this category</p>
            </div>
          )}
          {visible.map((inv) => {
            const student = students.find((s) => s.id === inv.studentId);
            return (
              <div
                key={inv.id}
                className="flex flex-wrap items-center gap-3 rounded-xl border border-lime-100 bg-white p-4 shadow-sm sm:flex-nowrap"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-lime-100 text-green-800">
                  <Receipt className="h-4 w-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-slate-800">{inv.studentName}</p>
                  <p className="text-xs text-slate-500">
                    {inv.id} · {inv.term} · due {inv.dueDate}
                    {student ? ` · ${student.grade} ${student.section}` : ""}
                  </p>
                </div>
                <p className="text-sm font-bold text-slate-900">${inv.amount.toLocaleString()}</p>
                <Badge variant="outline" className={statusChip[inv.status]}>
                  {inv.status}
                </Badge>
                {inv.status !== "paid" ? (
                  <Button
                    size="sm"
                    className="bg-green-600 text-white hover:bg-green-700"
                    onClick={() => payInvoice(inv.id)}
                  >
                    <CreditCard className="mr-1 h-3.5 w-3.5" /> Pay now
                  </Button>
                ) : (
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-lime-300 bg-lime-50 text-green-800 hover:bg-lime-100"
                    onClick={() => alert(`Receipt for ${inv.id} generated and emailed to guardian.`)}
                  >
                    Receipt
                  </Button>
                )}
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}