import { Check, Clock, X, Send } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import type { AttendanceStatus, Student } from "@/data/school";

const statusStyles: Record<AttendanceStatus, { label: string; chip: string; icon: typeof Check }> = {
  present: { label: "Present", chip: "bg-green-600 text-white", icon: Check },
  late: { label: "Late", chip: "bg-amber-500 text-white", icon: Clock },
  absent: { label: "Absent", chip: "bg-rose-600 text-white", icon: X },
};

function initials(name: string) {
  return name.split(" ").map((n) => n[0]).slice(0, 2).join("");
}

export function AttendanceView({
  students,
  setStudents,
}: {
  students: Student[];
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>;
}) {
  const present = students.filter((s) => s.attendanceToday === "present").length;
  const late = students.filter((s) => s.attendanceToday === "late").length;
  const absent = students.filter((s) => s.attendanceToday === "absent").length;
  const rate = students.length ? Math.round(((present + late) / students.length) * 100) : 0;

  const mark = (id: string, status: AttendanceStatus) =>
    setStudents((prev) => prev.map((s) => (s.id === id ? { ...s, attendanceToday: status } : s)));

  const markAllPresent = () =>
    setStudents((prev) => prev.map((s) => ({ ...s, attendanceToday: "present" as AttendanceStatus })));

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-4">
        <Card className="border-lime-200 bg-white shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium uppercase tracking-wide text-green-700">Register rate</p>
            <p className="mt-1 text-3xl font-bold text-green-800">{rate}%</p>
            <Progress value={rate} className="mt-3 h-1.5" />
          </CardContent>
        </Card>
        <Card className="border-green-200 bg-green-50 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium uppercase tracking-wide text-green-700">Present</p>
            <p className="mt-1 text-3xl font-bold text-green-800">{present}</p>
          </CardContent>
        </Card>
        <Card className="border-amber-200 bg-amber-50 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium uppercase tracking-wide text-amber-700">Late</p>
            <p className="mt-1 text-3xl font-bold text-amber-800">{late}</p>
          </CardContent>
        </Card>
        <Card className="border-rose-200 bg-rose-50 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium uppercase tracking-wide text-rose-700">Absent</p>
            <p className="mt-1 text-3xl font-bold text-rose-800">{absent}</p>
          </CardContent>
        </Card>
      </div>

      <Card className="border-lime-200 bg-white shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <div>
            <CardTitle className="font-serif text-lg text-green-900">Digital Register · Today</CardTitle>
            <p className="text-sm text-slate-500">One-tap marking · absentees trigger parent SMS alerts</p>
          </div>
          <Button onClick={markAllPresent} className="bg-green-600 text-white hover:bg-green-700">
            <Check className="mr-1 h-4 w-4" /> Mark all present
          </Button>
        </CardHeader>
        <CardContent className="space-y-2">
          {students.map((s) => {
            const style = statusStyles[s.attendanceToday];
            return (
              <div
                key={s.id}
                className="flex flex-wrap items-center gap-3 rounded-xl border border-lime-100 bg-white p-3 shadow-sm sm:flex-nowrap"
              >
                <Avatar className="h-10 w-10">
                  <AvatarFallback className="bg-lime-100 text-xs font-semibold text-green-900">
                    {initials(s.name)}
                  </AvatarFallback>
                </Avatar>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-slate-800">{s.name}</p>
                  <p className="text-xs text-slate-500">{s.grade} {s.section} · {s.attendanceRate}% term avg</p>
                </div>
                <Badge className={`${style.chip} hover:${style.chip}`}>
                  <style.icon className="mr-1 h-3 w-3" />
                  {style.label}
                </Badge>
                <div className="flex gap-1">
                  {(["present", "late", "absent"] as AttendanceStatus[]).map((st) => (
                    <button
                      key={st}
                      onClick={() => mark(s.id, st)}
                      className={`rounded-lg px-3 py-1.5 text-xs font-medium capitalize transition ${
                        s.attendanceToday === st
                          ? "bg-green-600 text-white"
                          : "bg-lime-50 text-green-800 hover:bg-lime-100"
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
                {s.attendanceToday === "absent" && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-rose-200 text-rose-700 hover:bg-rose-50"
                    onClick={() => alert(`SMS alert sent to ${s.guardian} (${s.guardianPhone})`)}
                  >
                    <Send className="mr-1 h-3.5 w-3.5" /> Alert parent
                  </Button>
                )}
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}