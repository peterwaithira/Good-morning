import { useState } from "react";
import { CalendarClock, AlertTriangle, UserCheck, DoorOpen } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { timetable } from "@/data/school";

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri"];

export function TimetableView() {
  const [day, setDay] = useState("Mon");
  const slots = timetable.filter((s) => s.day === day);
  const conflicts = timetable.filter((s) => s.conflict).length;
  const substitutes = timetable.filter((s) => s.substitute).length;

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-3">
        <Card className="border-lime-200 bg-white shadow-sm">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-lime-200 text-green-800">
              <CalendarClock className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs font-medium uppercase tracking-wide text-green-700">Scheduled periods</p>
              <p className="text-2xl font-bold text-slate-900">{timetable.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-amber-200 bg-amber-50 shadow-sm">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-200 text-amber-800">
              <AlertTriangle className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs font-medium uppercase tracking-wide text-amber-700">Conflicts flagged</p>
              <p className="text-2xl font-bold text-amber-900">{conflicts}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-teal-200 bg-teal-50 shadow-sm">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-teal-200 text-teal-800">
              <UserCheck className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs font-medium uppercase tracking-wide text-teal-700">Substitutes assigned</p>
              <p className="text-2xl font-bold text-teal-900">{substitutes}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-lime-200 bg-white shadow-sm">
        <CardHeader className="flex flex-row flex-wrap items-center justify-between gap-3 space-y-0">
          <div>
            <CardTitle className="font-serif text-lg text-green-900">Master Timetable</CardTitle>
            <p className="text-sm text-slate-500">Automated conflict-free scheduling for teachers, rooms & subjects</p>
          </div>
          <div className="flex gap-1 rounded-lg bg-lime-100 p-1">
            {DAYS.map((d) => (
              <button
                key={d}
                onClick={() => setDay(d)}
                className={`rounded-md px-3 py-1.5 text-xs font-medium transition ${
                  day === d ? "bg-white text-green-800 shadow-sm" : "text-green-700/70 hover:text-green-900"
                }`}
              >
                {d}
              </button>
            ))}
          </div>
        </CardHeader>
        <CardContent className="space-y-2">
          {slots.length === 0 && (
            <div className="rounded-xl border border-dashed border-lime-300 py-10 text-center">
              <CalendarClock className="mx-auto h-7 w-7 text-lime-500" />
              <p className="mt-2 text-sm font-medium text-slate-600">No periods scheduled for {day}</p>
            </div>
          )}
          {slots.map((s) => (
            <div
              key={s.day + s.time + s.grade}
              className={`flex flex-wrap items-center gap-3 rounded-xl border p-4 shadow-sm sm:flex-nowrap ${
                s.conflict ? "border-amber-300 bg-amber-50" : "border-lime-100 bg-white"
              }`}
            >
              <div className="flex w-16 items-center gap-1 text-sm font-semibold text-green-800">
                <CalendarClock className="h-3.5 w-3.5" />
                {s.time}
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold text-slate-800">{s.subject}</p>
                <p className="text-xs text-slate-500">
                  {s.teacher} · {s.room}
                  {s.substitute ? ` · substitute: ${s.substitute}` : ""}
                </p>
              </div>
              <Badge variant="outline" className="border-lime-300 bg-white text-green-800">{s.grade}</Badge>
              <Badge variant="outline" className="border-slate-200 bg-white text-slate-600">
                <DoorOpen className="mr-1 h-3 w-3" /> {s.room}
              </Badge>
              {s.conflict && (
                <Badge className="bg-amber-500 text-white hover:bg-amber-500">Conflict resolved</Badge>
              )}
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}