import { useMemo, useState } from "react";
import { Search, HeartPulse, Phone, GraduationCap } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { studentAverage, overallLevel, CBC_LEVELS, type Student } from "@/data/school";

function initials(name: string) {
  return name.split(" ").map((n) => n[0]).slice(0, 2).join("");
}

export function StudentsView({
  students,
  setStudents,
}: {
  students: Student[];
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>;
}) {
  const [query, setQuery] = useState("");
  const [grade, setGrade] = useState("all");
  const [selectedId, setSelectedId] = useState(students[0]?.id ?? "");

  const grades = useMemo(() => Array.from(new Set(students.map((s) => s.grade))).sort(), [students]);

  const filtered = students.filter((s) => {
    const matchesQuery =
      s.name.toLowerCase().includes(query.toLowerCase()) ||
      s.id.toLowerCase().includes(query.toLowerCase()) ||
      s.guardian.toLowerCase().includes(query.toLowerCase());
    const matchesGrade = grade === "all" || s.grade === grade;
    return matchesQuery && matchesGrade;
  });

  const selected = students.find((s) => s.id === selectedId) ?? filtered[0];

  return (
    <div className="grid gap-6 lg:grid-cols-5">
      <div className="lg:col-span-3">
        <div className="mb-4 flex flex-col gap-3 sm:flex-row">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-green-600" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by name, ID, or guardian…"
              className="border-lime-200 bg-white pl-9 focus-visible:ring-lime-400"
            />
          </div>
          <Select value={grade} onValueChange={setGrade}>
            <SelectTrigger className="w-full border-lime-200 bg-white sm:w-44">
              <SelectValue placeholder="Grade" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All grades</SelectItem>
              {grades.map((g) => (
                <SelectItem key={g} value={g}>{g}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          {filtered.length === 0 && (
            <Card className="border-dashed border-lime-300 bg-white">
              <CardContent className="py-12 text-center">
                <GraduationCap className="mx-auto h-8 w-8 text-lime-400" />
                <p className="mt-3 text-sm font-medium text-slate-600">No students match your search</p>
                <p className="text-xs text-slate-400">Try a different name, ID, or grade filter.</p>
              </CardContent>
            </Card>
          )}
          {filtered.map((s) => {
            const overall = overallLevel(s);
            const meta = CBC_LEVELS.find((l) => l.level === overall) ?? CBC_LEVELS[CBC_LEVELS.length - 1];
            return (
              <button
                key={s.id}
                onClick={() => setSelectedId(s.id)}
                className={`flex w-full items-center gap-4 rounded-xl border bg-white p-4 text-left shadow-sm transition ${
                  selected?.id === s.id
                    ? "border-lime-400 ring-2 ring-lime-200"
                    : "border-lime-100 hover:border-lime-300 hover:bg-lime-50/60"
                }`}
              >
                <Avatar className="h-11 w-11">
                  <AvatarFallback className="bg-lime-200 text-sm font-semibold text-green-900">
                    {initials(s.name)}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-semibold text-slate-800">{s.name}</p>
                    <span className="text-xs text-slate-400">{s.id}</span>
                  </div>
                  <p className="text-xs text-slate-500">
                    {s.grade} · Section {s.section} · {studentAverage(s).toFixed(2)} pts
                  </p>
                </div>
                <Badge className={`${meta.tone} hover:${meta.tone}`}>{overall}</Badge>
              </button>
            );
          })}
        </div>
      </div>

      <div className="lg:col-span-2">
        {selected && (
          <Card className="sticky top-6 border-lime-200 bg-white shadow-sm">
            <CardContent className="space-y-5 p-6">
              <div className="flex items-center gap-4">
                <Avatar className="h-14 w-14">
                  <AvatarFallback className="bg-gradient-to-br from-lime-400 to-green-600 text-base font-semibold text-white">
                    {initials(selected.name)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-serif text-lg font-bold text-slate-900">{selected.name}</h3>
                  <p className="text-xs text-slate-500">{selected.id} · {selected.grade} {selected.section}</p>
                </div>
              </div>

              <div className="rounded-xl bg-lime-50 p-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-500">Attendance rate</span>
                  <span className="font-semibold text-green-800">{selected.attendanceRate}%</span>
                </div>
                <Progress value={selected.attendanceRate} className="mt-2 h-2" />
              </div>

              <div className="space-y-3 text-sm">
                <div className="flex items-start gap-3">
                  <Phone className="mt-0.5 h-4 w-4 text-green-600" />
                  <div>
                    <p className="font-medium text-slate-800">{selected.guardian}</p>
                    <p className="text-xs text-slate-500">{selected.guardianPhone}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <HeartPulse className="mt-0.5 h-4 w-4 text-rose-500" />
                  <div>
                    <p className="font-medium text-slate-800">Health note</p>
                    <p className="text-xs text-slate-500">{selected.healthNote}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <GraduationCap className="mt-0.5 h-4 w-4 text-lime-600" />
                  <div>
                    <p className="font-medium text-slate-800">Academic standing</p>
                    <p className="text-xs text-slate-500">
                      CBC average {studentAverage(selected).toFixed(2)} pts · overall {overallLevel(selected)}
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() =>
                    setStudents((prev) =>
                      prev.map((s) => (s.id === selected.id ? { ...s, feeBalance: 0 } : s)),
                    )
                  }
                  className="flex-1 rounded-lg bg-green-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-green-700"
                >
                  Clear balance
                </button>
                <button
                  onClick={() =>
                    setStudents((prev) =>
                      prev.map((s) =>
                        s.id === selected.id ? { ...s, attendanceRate: Math.min(100, s.attendanceRate + 1) } : s,
                      ),
                    )
                  }
                  className="flex-1 rounded-lg border border-lime-300 bg-lime-50 px-4 py-2 text-sm font-medium text-green-800 transition hover:bg-lime-100"
                >
                  Log attendance
                </button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}