import { useState } from "react";
import { Users2, Wallet, CalendarDays, CheckCircle2, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { initialStaff, type Staff } from "@/data/school";

const statusChip: Record<Staff["status"], string> = {
  "on duty": "border-green-200 bg-green-50 text-green-700",
  "on leave": "border-amber-200 bg-amber-50 text-amber-700",
  absent: "border-rose-200 bg-rose-50 text-rose-700",
};

function initials(name: string) {
  return name.replace(/^(Mr\.|Ms\.|Mrs\.|Mwl\.|Coach|Pastor)\s+/, "").split(" ").map((n) => n[0]).slice(0, 2).join("");
}

export function HrView() {
  const [staff, setStaff] = useState<Staff[]>(initialStaff);

  const onDuty = staff.filter((s) => s.status === "on duty").length;
  const payroll = staff.reduce((a, s) => a + s.grossPay, 0);
  const onLeave = staff.filter((s) => s.status === "on leave").length;

  const approveLeave = (id: string) =>
    setStaff((prev) => prev.map((s) => (s.id === id ? { ...s, status: "on duty", leaveBalance: Math.max(0, s.leaveBalance - 1) } : s)));

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-3">
        <Card className="border-lime-200 bg-white shadow-sm">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-lime-200 text-green-800">
              <Users2 className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs font-medium uppercase tracking-wide text-green-700">Staff on duty</p>
              <p className="text-2xl font-bold text-slate-900">{onDuty}<span className="text-sm font-normal text-slate-400"> / {staff.length}</span></p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-teal-200 bg-teal-50 shadow-sm">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-teal-200 text-teal-800">
              <Wallet className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs font-medium uppercase tracking-wide text-teal-700">Monthly payroll</p>
              <p className="text-2xl font-bold text-teal-900">${payroll.toLocaleString()}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-amber-200 bg-amber-50 shadow-sm">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-200 text-amber-800">
              <CalendarDays className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs font-medium uppercase tracking-wide text-amber-700">On leave</p>
              <p className="text-2xl font-bold text-amber-900">{onLeave}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-lime-200 bg-white shadow-sm">
        <CardHeader>
          <CardTitle className="font-serif text-lg text-green-900">Staff Profiles & Digital Attendance</CardTitle>
          <p className="text-sm text-slate-500">Biometric check-in · leave approvals · automated payslips</p>
        </CardHeader>
        <CardContent className="space-y-2">
          {staff.map((s) => (
            <div
              key={s.id}
              className="flex flex-wrap items-center gap-3 rounded-xl border border-lime-100 bg-white p-4 shadow-sm sm:flex-nowrap"
            >
              <Avatar className="h-10 w-10">
                <AvatarFallback className="bg-lime-100 text-xs font-semibold text-green-900">
                  {initials(s.name)}
                </AvatarFallback>
              </Avatar>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold text-slate-800">{s.name}</p>
                <p className="text-xs text-slate-500">{s.role} · {s.department}</p>
              </div>
              <div className="hidden flex-wrap gap-1 md:flex">
                {s.subjects.map((sub) => (
                  <span key={sub} className="rounded bg-lime-50 px-2 py-0.5 text-xs font-medium text-green-800">{sub}</span>
                ))}
              </div>
              <span className="text-xs text-slate-500">{s.leaveBalance} leave days</span>
              <span className="text-sm font-semibold text-slate-700">${s.grossPay.toLocaleString()}</span>
              <Badge variant="outline" className={statusChip[s.status]}>{s.status}</Badge>
              {s.status === "on leave" ? (
                <Button
                  size="sm"
                  className="bg-green-600 text-white hover:bg-green-700"
                  onClick={() => approveLeave(s.id)}
                >
                  <CheckCircle2 className="mr-1 h-3.5 w-3.5" /> Approve
                </Button>
              ) : (
                <Button
                  size="sm"
                  variant="outline"
                  className="border-lime-300 bg-lime-50 text-green-800 hover:bg-lime-100"
                  onClick={() => alert(`Payslip for ${s.name} generated for Term 2, 2025.`)}
                >
                  <Clock className="mr-1 h-3.5 w-3.5" /> Payslip
                </Button>
              )}
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}