import type { ReactNode } from "react";
import {
  LayoutDashboard,
  Users,
  CalendarCheck,
  ClipboardList,
  Wallet,
  CalendarClock,
  Users2,
  Bus,
  Bell,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import type { TabKey } from "@/App";

type Stats = {
  total: number;
  presentToday: number;
  attendanceRate: number;
  collected: number;
  outstanding: number;
  avgPoints: number;
};

const nav: { key: TabKey; label: string; icon: typeof Users }[] = [
  { key: "dashboard", label: "Overview", icon: LayoutDashboard },
  { key: "students", label: "Students", icon: Users },
  { key: "attendance", label: "Attendance", icon: CalendarCheck },
  { key: "timetable", label: "Timetable", icon: CalendarClock },
  { key: "gradebook", label: "Gradebook", icon: ClipboardList },
  { key: "fees", label: "Fees", icon: Wallet },
  { key: "hr", label: "HR & Payroll", icon: Users2 },
  { key: "transport", label: "Transport & Hostel", icon: Bus },
];

export function AppShell({
  tab,
  onTabChange,
  stats,
  icon,
  children,
}: {
  tab: TabKey;
  onTabChange: (t: TabKey) => void;
  stats: Stats;
  icon: ReactNode;
  children: ReactNode;
}) {
  return (
    <div className="min-h-screen bg-lime-50 text-slate-900">
      <header className="bg-gradient-to-r from-lime-500 via-green-500 to-emerald-500 text-white">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-6 py-5">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/20 ring-1 ring-white/40">
              {icon}
            </div>
            <div>
              <h1 className="font-serif text-xl font-bold leading-tight tracking-tight drop-shadow-sm">NICEREEN SCHOOL</h1>
              <p className="text-xs text-lime-50/90">Academic Operations Console · Term 2, 2025</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Badge className="hidden border-white/30 bg-white/20 text-white hover:bg-white/20 sm:inline-flex">
              {stats.total} students enrolled
            </Badge>
            <button className="relative rounded-full p-2 transition hover:bg-white/20" aria-label="Notifications">
              <Bell className="h-5 w-5" />
              <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-lime-200 ring-2 ring-green-500" />
            </button>
            <Avatar className="h-9 w-9 ring-2 ring-white/50">
              <AvatarFallback className="bg-green-700 text-xs font-semibold text-white">AD</AvatarFallback>
            </Avatar>
          </div>
        </div>
        <nav className="mx-auto flex max-w-7xl gap-1 overflow-x-auto px-4">
          {nav.map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => onTabChange(key)}
              className={cn(
                "flex items-center gap-2 whitespace-nowrap rounded-t-lg px-4 py-3 text-sm font-medium transition",
                tab === key
                  ? "bg-lime-50 text-green-800 shadow-sm"
                  : "text-lime-50/90 hover:bg-white/15 hover:text-white",
              )}
            >
              <Icon className="h-4 w-4" />
              {label}
            </button>
          ))}
        </nav>
      </header>
      <main className="mx-auto max-w-7xl px-6 py-8">{children}</main>
    </div>
  );
}