import { Users, CalendarCheck, Wallet, TrendingUp, ArrowRight, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  timetable,
  studentAverage,
  overallLevel,
  CBC_LEVELS,
  type Student,
  type Invoice,
} from "@/data/school";
import type { TabKey } from "@/App";

type Stats = {
  total: number;
  presentToday: number;
  attendanceRate: number;
  collected: number;
  outstanding: number;
  avgPoints: number;
};

function StatCard({
  label,
  value,
  sub,
  icon: Icon,
  tone,
}: {
  label: string;
  value: string;
  sub: string;
  icon: typeof Users;
  tone: string;
}) {
  return (
    <Card className="border-lime-200 bg-white shadow-sm transition hover:shadow-md">
      <CardContent className="flex items-start justify-between p-5">
        <div>
          <p className="text-xs font-medium uppercase tracking-wide text-green-700">{label}</p>
          <p className="mt-2 text-3xl font-bold tracking-tight text-slate-900">{value}</p>
          <p className="mt-1 text-xs text-slate-500">{sub}</p>
        </div>
        <div className={`flex h-11 w-11 items-center justify-center rounded-xl ${tone}`}>
          <Icon className="h-5 w-5" />
        </div>
      </CardContent>
    </Card>
  );
}

export function DashboardView({
  students,
  invoices,
  stats,
  onNavigate,
}: {
  students: Student[];
  invoices: Invoice[];
  stats: Stats;
  onNavigate: (t: TabKey) => void;
}) {
  const defaulters = invoices.filter((i) => i.status !== "paid");
  const topStudents = [...students].sort((a, b) => studentAverage(b) - studentAverage(a)).slice(0, 4);

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Enrolled Students" value={String(stats.total)} sub="Across 4 grade levels" icon={Users} tone="bg-lime-200 text-green-800" />
        <StatCard label="Attendance Today" value={`${stats.attendanceRate}%`} sub={`${stats.presentToday} of ${stats.total} present`} icon={CalendarCheck} tone="bg-green-200 text-green-800" />
        <StatCard label="Fees Collected" value={`$${stats.collected.toLocaleString()}`} sub="Term 2 receipts issued" icon={Wallet} tone="bg-emerald-200 text-emerald-800" />
        <StatCard label="Avg CBC Points" value={stats.avgPoints.toFixed(2)} sub="School-wide, 8-point scale" icon={TrendingUp} tone="bg-teal-200 text-teal-800" />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="border-lime-200 bg-white shadow-sm lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <div>
              <CardTitle className="font-serif text-lg text-green-900">Today's Timetable</CardTitle>
              <p className="text-sm text-slate-500">Conflict-free schedule · substitute coverage active</p>
            </div>
            <Badge className="bg-lime-200 text-green-900 hover:bg-lime-200">Live</Badge>
          </CardHeader>
          <CardContent className="space-y-2">
            {timetable.map((slot) => (
              <div
                key={slot.time + slot.subject}
                className="flex items-center gap-4 rounded-xl border border-lime-100 bg-lime-50/60 px-4 py-3 transition hover:border-lime-300 hover:bg-lime-100/60"
              >
                <div className="flex w-16 items-center gap-1 text-sm font-semibold text-green-800">
                  <Clock className="h-3.5 w-3.5" />
                  {slot.time}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-slate-800">{slot.subject}</p>
                  <p className="text-xs text-slate-500">{slot.teacher} · {slot.room}</p>
                </div>
                <Badge variant="outline" className="border-lime-300 bg-white text-green-800">{slot.grade}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="border-amber-200 bg-white shadow-sm">
          <CardHeader>
            <CardTitle className="font-serif text-lg text-amber-900">Fee Defaulters</CardTitle>
            <p className="text-sm text-slate-500">{defaulters.length} accounts need follow-up</p>
          </CardHeader>
          <CardContent className="space-y-3">
            {defaulters.slice(0, 4).map((inv) => (
              <div key={inv.id} className="rounded-xl border border-amber-100 bg-amber-50/70 p-3">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold text-slate-800">{inv.studentName}</p>
                  <span className="text-sm font-bold text-amber-700">${inv.amount}</span>
                </div>
                <p className="mt-0.5 text-xs text-slate-500">{inv.id} · due {inv.dueDate}</p>
              </div>
            ))}
            <Button
              variant="outline"
              className="w-full border-lime-300 bg-lime-50 text-green-800 hover:bg-lime-100"
              onClick={() => onNavigate("fees")}
            >
              Manage invoices <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card className="border-lime-200 bg-white shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <div>
            <CardTitle className="font-serif text-lg text-green-900">Top Performers</CardTitle>
            <p className="text-sm text-slate-500">Ranked by CBC competency average this term</p>
          </div>
          <Button
            variant="outline"
            className="border-lime-300 bg-lime-50 text-green-800 hover:bg-lime-100"
            onClick={() => onNavigate("gradebook")}
          >
            Open gradebook <ArrowRight className="ml-1 h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {topStudents.map((s) => {
            const overall = overallLevel(s);
            const meta = CBC_LEVELS.find((l) => l.level === overall) ?? CBC_LEVELS[CBC_LEVELS.length - 1];
            return (
              <div key={s.id} className="rounded-xl border border-lime-100 bg-gradient-to-br from-lime-50 to-green-50 p-4">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold text-slate-800">{s.name}</p>
                  <Badge className={`${meta.tone} hover:${meta.tone}`}>{overall}</Badge>
                </div>
                <p className="mt-1 text-xs text-slate-500">{s.grade} · Section {s.section}</p>
                <Progress value={(studentAverage(s) / 8) * 100} className="mt-3 h-1.5" />
                <p className="mt-1.5 text-xs text-slate-500">{studentAverage(s).toFixed(2)} avg points</p>
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}