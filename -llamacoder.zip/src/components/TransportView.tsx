import { Bus, BedDouble, MapPin, Users } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { initialRoutes, initialHostels, type Route } from "@/data/school";

const routeChip: Record<Route["status"], string> = {
  "on route": "border-green-200 bg-green-50 text-green-700",
  completed: "border-slate-200 bg-slate-50 text-slate-600",
  delayed: "border-rose-200 bg-rose-50 text-rose-700",
};

export function TransportView() {
  const totalOnboard = initialRoutes.reduce((a, r) => a + r.onboard, 0);
  const totalCapacity = initialRoutes.reduce((a, r) => a + r.capacity, 0);
  const hostelBeds = initialHostels.reduce((a, h) => a + h.capacity, 0);
  const hostelOccupied = initialHostels.reduce((a, h) => a + h.occupied, 0);

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="border-lime-200 bg-white shadow-sm">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-lime-200 text-green-800">
              <Bus className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs font-medium uppercase tracking-wide text-green-700">Active routes</p>
              <p className="text-2xl font-bold text-slate-900">{initialRoutes.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-teal-200 bg-teal-50 shadow-sm">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-teal-200 text-teal-800">
              <Users className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs font-medium uppercase tracking-wide text-teal-700">Students onboard</p>
              <p className="text-2xl font-bold text-teal-900">{totalOnboard}<span className="text-sm font-normal text-teal-600"> / {totalCapacity}</span></p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-emerald-200 bg-emerald-50 shadow-sm">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-200 text-emerald-800">
              <BedDouble className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs font-medium uppercase tracking-wide text-emerald-700">Hostel beds filled</p>
              <p className="text-2xl font-bold text-emerald-900">{hostelOccupied}<span className="text-sm font-normal text-emerald-600"> / {hostelBeds}</span></p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-amber-200 bg-amber-50 shadow-sm">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-200 text-amber-800">
              <MapPin className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs font-medium uppercase tracking-wide text-amber-700">Total stops</p>
              <p className="text-2xl font-bold text-amber-900">{initialRoutes.reduce((a, r) => a + r.stops, 0)}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="border-lime-200 bg-white shadow-sm">
          <CardHeader>
            <CardTitle className="font-serif text-lg text-green-900">Transport Routes & Logs</CardTitle>
            <p className="text-sm text-slate-500">Route assignment, driver logs & live occupancy</p>
          </CardHeader>
          <CardContent className="space-y-3">
            {initialRoutes.map((r) => (
              <div key={r.id} className="rounded-xl border border-lime-100 bg-white p-4 shadow-sm">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <p className="text-sm font-semibold text-slate-800">{r.name}</p>
                    <p className="text-xs text-slate-500">{r.driver} · {r.vehicle} · {r.stops} stops</p>
                  </div>
                  <Badge variant="outline" className={routeChip[r.status]}>{r.status}</Badge>
                </div>
                <div className="mt-3 flex items-center gap-3">
                  <Progress value={(r.onboard / r.capacity) * 100} className="h-1.5 flex-1" />
                  <span className="text-xs font-medium text-slate-500">{r.onboard}/{r.capacity}</span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="border-lime-200 bg-white shadow-sm">
          <CardHeader>
            <CardTitle className="font-serif text-lg text-green-900">Hostel Management</CardTitle>
            <p className="text-sm text-slate-500">Boarding houses, occupancy & house matrons</p>
          </CardHeader>
          <CardContent className="space-y-3">
            {initialHostels.map((h) => (
              <div key={h.id} className="rounded-xl border border-lime-100 bg-white p-4 shadow-sm">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <p className="text-sm font-semibold text-slate-800">{h.name}</p>
                    <p className="text-xs text-slate-500">{h.gender} · {h.matron}</p>
                  </div>
                  <Badge
                    variant="outline"
                    className={h.occupied / h.capacity > 0.9 ? "border-amber-200 bg-amber-50 text-amber-700" : "border-lime-300 bg-lime-50 text-green-800"}
                  >
                    {Math.round((h.occupied / h.capacity) * 100)}% full
                  </Badge>
                </div>
                <div className="mt-3 flex items-center gap-3">
                  <Progress value={(h.occupied / h.capacity) * 100} className="h-1.5 flex-1" />
                  <span className="text-xs font-medium text-slate-500">{h.occupied}/{h.capacity}</span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}