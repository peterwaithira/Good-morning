import { useMemo, useState } from "react";
import { GraduationCap } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { DashboardView } from "@/components/DashboardView";
import { StudentsView } from "@/components/StudentsView";
import { AttendanceView } from "@/components/AttendanceView";
import { TimetableView } from "@/components/TimetableView";
import { GradebookView } from "@/components/GradebookView";
import { FeesView } from "@/components/FeesView";
import { HrView } from "@/components/HrView";
import { TransportView } from "@/components/TransportView";
import {
  initialStudents,
  initialInvoices,
  studentAverage,
  SCHOOL_TOTAL_STUDENTS,
  type Student,
  type Invoice,
} from "@/data/school";

export type TabKey =
  | "dashboard"
  | "students"
  | "attendance"
  | "timetable"
  | "gradebook"
  | "fees"
  | "hr"
  | "transport";

export default function App() {
  const [tab, setTab] = useState<TabKey>("dashboard");
  const [students, setStudents] = useState<Student[]>(initialStudents);
  const [invoices, setInvoices] = useState<Invoice[]>(initialInvoices);

  const stats = useMemo(() => {
    const presentToday = students.filter((s) => s.attendanceToday === "present").length;
    const attendanceRate = students.length
      ? Math.round(((presentToday + students.filter((s) => s.attendanceToday === "late").length) / students.length) * 100)
      : 0;
    const collected = invoices.filter((i) => i.status === "paid").reduce((a, i) => a + i.amount, 0);
    const outstanding = invoices.filter((i) => i.status !== "paid").reduce((a, i) => a + i.amount, 0);
    const avgPoints = students.length
      ? students.reduce((a, s) => a + studentAverage(s), 0) / students.length
      : 0;
    return {
      total: SCHOOL_TOTAL_STUDENTS,
      presentToday,
      attendanceRate,
      collected,
      outstanding,
      avgPoints,
    };
  }, [students, invoices]);

  return (
    <AppShell
      tab={tab}
      onTabChange={setTab}
      stats={stats}
      icon={<GraduationCap className="h-6 w-6 text-white" />}
    >
      {tab === "dashboard" && (
        <DashboardView students={students} invoices={invoices} stats={stats} onNavigate={setTab} />
      )}
      {tab === "students" && <StudentsView students={students} setStudents={setStudents} />}
      {tab === "attendance" && <AttendanceView students={students} setStudents={setStudents} />}
      {tab === "timetable" && <TimetableView />}
      {tab === "gradebook" && <GradebookView students={students} setStudents={setStudents} />}
      {tab === "fees" && <FeesView invoices={invoices} setInvoices={setInvoices} students={students} />}
      {tab === "hr" && <HrView />}
      {tab === "transport" && <TransportView />}
    </AppShell>
  );
}